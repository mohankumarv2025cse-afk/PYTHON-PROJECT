from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from pymongo import MongoClient
from datetime import datetime, timedelta
import os
import json
import hashlib
import re

app = Flask(__name__)
app.secret_key = "travel_regret_secret_2026"

# ─── MongoDB Connection ───────────────────────────────────────────────────────
try:
    client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=3000)
    client.server_info()
    db = client["travel_regret_db"]
    users_col       = db["users"]
    trips_col       = db["trips"]
    checklists_col  = db["checklists"]
    reviews_col     = db["reviews"]
    print("✅ MongoDB connected successfully.")
except Exception as e:
    print(f"❌ MongoDB connection failed: {e}")
    db = None

# ─── Helpers ──────────────────────────────────────────────────────────────────
def hash_password(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

def logged_in():
    return "user_id" in session

def current_user():
    if not logged_in():
        return None
    return users_col.find_one({"_id": session["user_id"]}) if db else None

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", logged_in=logged_in())

@app.route("/dashboard")
def dashboard():
    if not logged_in():
        return redirect(url_for("login"))
    trips = list(trips_col.find({"user_id": session["user_id"]}).sort("created_at", -1)) if db else []
    for t in trips:
        t["_id"] = str(t["_id"])
    return render_template("dashboard.html", trips=trips, username=session.get("username"))

@app.route("/plan")
def plan():
    if not logged_in():
        return redirect(url_for("login"))
    return render_template("plan.html", username=session.get("username"))

@app.route("/checklist")
def checklist():
    if not logged_in():
        return redirect(url_for("login"))
    return render_template("checklist.html", username=session.get("username"))

@app.route("/reviews")
def reviews():
    if not logged_in():
        return redirect(url_for("login"))
    all_reviews = list(reviews_col.find({}).sort("created_at", -1).limit(20)) if db else []
    for r in all_reviews:
        r["_id"] = str(r["_id"])
    return render_template("reviews.html", reviews=all_reviews, username=session.get("username"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        data = request.get_json()
        email    = data.get("email", "").strip().lower()
        password = data.get("password", "")
        if not db:
            return jsonify({"success": False, "message": "Database not connected."})
        user = users_col.find_one({"email": email, "password": hash_password(password)})
        if user:
            session["user_id"]  = str(user["_id"])
            session["username"] = user["name"]
            return jsonify({"success": True, "redirect": url_for("dashboard")})
        return jsonify({"success": False, "message": "Invalid email or password."})
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        data = request.get_json()
        name     = data.get("name", "").strip()
        email    = data.get("email", "").strip().lower()
        password = data.get("password", "")
        if not db:
            return jsonify({"success": False, "message": "Database not connected."})
        if users_col.find_one({"email": email}):
            return jsonify({"success": False, "message": "Email already registered."})
        users_col.insert_one({
            "name":       name,
            "email":      email,
            "password":   hash_password(password),
            "created_at": datetime.now()
        })
        return jsonify({"success": True, "redirect": url_for("login")})
    return render_template("register.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

# ─── API: Trips ───────────────────────────────────────────────────────────────

@app.route("/api/trips", methods=["GET"])
def get_trips():
    if not logged_in() or not db:
        return jsonify([])
    trips = list(trips_col.find({"user_id": session["user_id"]}).sort("created_at", -1))
    for t in trips:
        t["_id"] = str(t["_id"])
    return jsonify(trips)

@app.route("/api/trips", methods=["POST"])
def add_trip():
    if not logged_in():
        return jsonify({"success": False, "message": "Not logged in."})
    data = request.get_json()
    required = ["destination", "start_date", "end_date", "budget", "trip_type"]
    for f in required:
        if not data.get(f):
            return jsonify({"success": False, "message": f"Missing field: {f}"})

    # Regret-prevention score calculation
    score = calculate_regret_score(data)

    trip = {
        "user_id":      session["user_id"],
        "destination":  data["destination"],
        "start_date":   data["start_date"],
        "end_date":     data["end_date"],
        "budget":       float(data["budget"]),
        "trip_type":    data["trip_type"],
        "companions":   data.get("companions", "Solo"),
        "activities":   data.get("activities", []),
        "notes":        data.get("notes", ""),
        "regret_score": score,
        "status":       "planned",
        "created_at":   datetime.now()
    }
    result = trips_col.insert_one(trip)
    trip["_id"] = str(result.inserted_id)
    return jsonify({"success": True, "trip": trip})

@app.route("/api/trips/<trip_id>", methods=["DELETE"])
def delete_trip(trip_id):
    if not logged_in() or not db:
        return jsonify({"success": False})
    from bson import ObjectId
    trips_col.delete_one({"_id": ObjectId(trip_id), "user_id": session["user_id"]})
    return jsonify({"success": True})

@app.route("/api/trips/<trip_id>/status", methods=["PUT"])
def update_trip_status(trip_id):
    if not logged_in() or not db:
        return jsonify({"success": False})
    from bson import ObjectId
    data = request.get_json()
    trips_col.update_one(
        {"_id": ObjectId(trip_id), "user_id": session["user_id"]},
        {"$set": {"status": data.get("status", "planned")}}
    )
    return jsonify({"success": True})

# ─── API: Checklist ───────────────────────────────────────────────────────────

@app.route("/api/checklist", methods=["GET"])
def get_checklist():
    if not logged_in() or not db:
        return jsonify([])
    items = list(checklists_col.find({"user_id": session["user_id"]}).sort("created_at", 1))
    for i in items:
        i["_id"] = str(i["_id"])
    return jsonify(items)

@app.route("/api/checklist", methods=["POST"])
def add_checklist_item():
    if not logged_in():
        return jsonify({"success": False})
    data = request.get_json()
    item = {
        "user_id":    session["user_id"],
        "text":       data.get("text", "").strip(),
        "category":   data.get("category", "General"),
        "checked":    False,
        "created_at": datetime.now()
    }
    result = checklists_col.insert_one(item)
    item["_id"] = str(result.inserted_id)
    return jsonify({"success": True, "item": item})

@app.route("/api/checklist/<item_id>", methods=["PUT"])
def toggle_checklist_item(item_id):
    if not logged_in() or not db:
        return jsonify({"success": False})
    from bson import ObjectId
    item = checklists_col.find_one({"_id": ObjectId(item_id)})
    if item:
        checklists_col.update_one({"_id": ObjectId(item_id)}, {"$set": {"checked": not item["checked"]}})
    return jsonify({"success": True})

@app.route("/api/checklist/<item_id>", methods=["DELETE"])
def delete_checklist_item(item_id):
    if not logged_in() or not db:
        return jsonify({"success": False})
    from bson import ObjectId
    checklists_col.delete_one({"_id": ObjectId(item_id)})
    return jsonify({"success": True})

# ─── API: Reviews ─────────────────────────────────────────────────────────────

@app.route("/api/reviews", methods=["POST"])
def add_review():
    if not logged_in():
        return jsonify({"success": False})
    data = request.get_json()
    review = {
        "user_id":     session["user_id"],
        "username":    session.get("username"),
        "destination": data.get("destination", "").strip(),
        "rating":      int(data.get("rating", 3)),
        "comment":     data.get("comment", "").strip(),
        "regret":      data.get("regret", "No"),
        "regret_reason": data.get("regret_reason", ""),
        "tips":        data.get("tips", ""),
        "created_at":  datetime.now()
    }
    result = reviews_col.insert_one(review)
    review["_id"] = str(result.inserted_id)
    return jsonify({"success": True, "review": review})

# ─── API: Analytics ──────────────────────────────────────────────────────────

@app.route("/api/analytics", methods=["GET"])
def analytics():
    if not logged_in() or not db:
        return jsonify({})
    uid = session["user_id"]
    trips = list(trips_col.find({"user_id": uid}))
    total   = len(trips)
    planned  = sum(1 for t in trips if t.get("status") == "planned")
    completed = sum(1 for t in trips if t.get("status") == "completed")
    total_budget = sum(t.get("budget", 0) for t in trips)
    avg_score = (sum(t.get("regret_score", 50) for t in trips) / total) if total else 0
    type_counts = {}
    for t in trips:
        k = t.get("trip_type", "Other")
        type_counts[k] = type_counts.get(k, 0) + 1
    return jsonify({
        "total": total,
        "planned": planned,
        "completed": completed,
        "total_budget": round(total_budget, 2),
        "avg_regret_score": round(avg_score, 1),
        "trip_types": type_counts
    })

# ─── Regret Score Calculator ──────────────────────────────────────────────────

def calculate_regret_score(data):
    """
    Higher score = lower regret risk (better trip).
    Score range: 0 – 100
    """
    score = 50  # baseline

    # Budget adequacy
    budget = float(data.get("budget", 0))
    if budget >= 2000:
        score += 15
    elif budget >= 1000:
        score += 10
    elif budget >= 500:
        score += 5
    else:
        score -= 10

    # Trip duration
    try:
        s = datetime.strptime(data["start_date"], "%Y-%m-%d")
        e = datetime.strptime(data["end_date"],   "%Y-%m-%d")
        days = (e - s).days
        if 5 <= days <= 14:
            score += 15
        elif 3 <= days < 5:
            score += 8
        elif days > 14:
            score += 5
        else:
            score -= 5
    except Exception:
        pass

    # Activities planned
    activities = data.get("activities", [])
    score += min(len(activities) * 3, 15)

    # Companions
    companion = data.get("companions", "Solo")
    companion_bonus = {"Solo": 5, "Couple": 10, "Family": 8, "Friends": 12, "Group": 7}
    score += companion_bonus.get(companion, 5)

    # Trip type
    trip_bonus = {"Beach": 10, "Adventure": 8, "Cultural": 12, "Road Trip": 9,
                  "City Break": 7, "Nature": 11, "Cruise": 6, "Other": 5}
    score += trip_bonus.get(data.get("trip_type", "Other"), 5)

    return min(max(int(score), 0), 100)

# ─── Run ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=True, port=5000)
