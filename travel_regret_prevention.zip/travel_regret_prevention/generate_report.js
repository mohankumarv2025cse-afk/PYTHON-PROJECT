const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
  ShadingType, VerticalAlign, PageBreak, LevelFormat,
  SimpleField
} = require("docx");
const fs = require("fs");

const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };

function heading1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    children: [new TextRun({ text, bold: true, size: 32, font: "Arial" })]
  });
}
function heading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text, bold: true, size: 26, font: "Arial" })]
  });
}
function para(text, opts = {}) {
  return new Paragraph({
    spacing: { before: 100, after: 120 },
    alignment: opts.center ? AlignmentType.CENTER : AlignmentType.JUSTIFIED,
    children: [new TextRun({ text, size: 22, font: "Arial", ...opts })]
  });
}
function bold(text) {
  return new Paragraph({
    spacing: { before: 80, after: 80 },
    children: [new TextRun({ text, bold: true, size: 22, font: "Arial" })]
  });
}
function bullet(text) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { before: 60, after: 60 },
    children: [new TextRun({ text, size: 22, font: "Arial" })]
  });
}
function br() { return new Paragraph({ children: [new TextRun("")] }); }

function tableRow(cells, isHeader = false) {
  return new TableRow({
    children: cells.map(text => new TableCell({
      borders,
      width: { size: Math.floor(9360 / cells.length), type: WidthType.DXA },
      shading: isHeader ? { fill: "4F46E5", type: ShadingType.CLEAR } : { fill: "F8F9FF", type: ShadingType.CLEAR },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({
        alignment: AlignmentType.LEFT,
        children: [new TextRun({ text, bold: isHeader, size: isHeader ? 20 : 20, color: isHeader ? "FFFFFF" : "111111", font: "Arial" })]
      })]
    }))
  });
}

const doc = new Document({
  numbering: {
    config: [{
      reference: "bullets",
      levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } } }]
    }]
  },
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 36, bold: true, color: "4F46E5", font: "Arial" },
        paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0,
          border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "4F46E5", space: 1 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, color: "1E293B", font: "Arial" },
        paragraph: { spacing: { before: 240, after: 140 }, outlineLevel: 1 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1080, bottom: 1440, left: 1440 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "4F46E5", space: 1 } },
          children: [new TextRun({ text: "Travel Regret Prevention System – Project Report", size: 18, color: "6B7280", font: "Arial" })]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          border: { top: { style: BorderStyle.SINGLE, size: 4, color: "4F46E5", space: 1 } },
          children: [
            new TextRun({ text: "Sri Eshwar College of Engineering – CSE Dept  |  Page ", size: 18, color: "6B7280", font: "Arial" }),
            new SimpleField("PAGE")
          ]
        })]
      })
    },
    children: [
      // ── TITLE PAGE ────────────────────────────────────────────
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 800, after: 200 },
        children: [new TextRun({ text: "TRAVEL REGRET PREVENTION SYSTEM", bold: true, size: 48, color: "4F46E5", font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 100, after: 400 },
        children: [new TextRun({ text: "An AI-Powered Trip Planning & Regret Scoring Web Application", size: 26, color: "475569", font: "Arial", italics: true })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 200 },
        children: [new TextRun({ text: "PROJECT REPORT SUBMITTED IN PARTIAL FULFILLMENT OF THE REQUIREMENTS", bold: true, size: 22, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 200 },
        children: [new TextRun({ text: "FOR THE AWARD OF THE DEGREE OF BACHELOR OF ENGINEERING", bold: true, size: 22, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 200 },
        children: [new TextRun({ text: "IN COMPUTER SCIENCE AND ENGINEERING", bold: true, size: 22, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 200 },
        children: [new TextRun({ text: "OF THE ANNA UNIVERSITY", bold: true, size: 22, font: "Arial" })] }),
      br(), br(),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 200, after: 100 },
        children: [new TextRun({ text: "Submitted by", size: 22, font: "Arial", italics: true })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 200 },
        children: [new TextRun({ text: "NETHRA V D – 722825104147", bold: true, size: 26, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 80 },
        children: [new TextRun({ text: "BATCH: 2025–2029", bold: true, size: 22, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 200, after: 80 },
        children: [new TextRun({ text: "Under the Guidance of", size: 22, font: "Arial", italics: true })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 80 },
        children: [new TextRun({ text: "Dr. M. Suriya, M.E., PhD.", bold: true, size: 22, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 600 },
        children: [new TextRun({ text: "Assistant Professor", size: 22, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 400, after: 100 },
        children: [new TextRun({ text: "DEPARTMENT OF COMPUTER SCIENCE AND ENGINEERING", bold: true, size: 24, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 80 },
        children: [new TextRun({ text: "Sri Eshwar College of Engineering", bold: true, size: 24, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 80 },
        children: [new TextRun({ text: "(An Autonomous Institution – Affiliated to Anna University)", size: 20, font: "Arial" })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 80 },
        children: [new TextRun({ text: "COIMBATORE – 641 202", bold: true, size: 22, font: "Arial" })] }),
      new Paragraph({ children: [new PageBreak()] }),

      // ── ABSTRACT ─────────────────────────────────────────────
      heading1("ABSTRACT"),
      para("This project presents the design and implementation of the Travel Regret Prevention System (TRPS), an intelligent full-stack web application developed using Python (Flask) as the backend framework, MongoDB as the NoSQL database, and a responsive HTML/CSS/JavaScript frontend. The system is engineered to assist travellers in planning their trips systematically, evaluating potential regret factors, and learning from community experiences."),
      para("The core innovation of the project is the Regret Prevention Score — a proprietary algorithm that analyses key trip parameters such as budget adequacy, trip duration, number of planned activities, type of travel companions, and category of trip to generate a score between 0 and 100. A higher score indicates a well-planned trip with lower regret risk, while a lower score signals areas the user should improve before finalising their travel plans."),
      para("Additional features include a smart, category-organised travel checklist with quick-add templates for different trip types (Beach, Adventure, Business, City Break), a persistent MongoDB-backed data layer, user authentication with session management, a community review system where travellers share post-trip experiences and regret indicators, and an analytics dashboard showing trip statistics and spending patterns."),
      para("By combining intelligent scoring, structured planning tools, and peer-sourced reviews into a single cohesive platform, the Travel Regret Prevention System addresses a genuine gap in modern travel planning tools and contributes meaningfully to improved traveller satisfaction and public leisure quality."),
      new Paragraph({ children: [new PageBreak()] }),

      // ── TABLE OF CONTENTS ─────────────────────────────────────
      heading1("TABLE OF CONTENTS"),
      ...[
        ["1.", "Introduction", "2"],
        ["2.", "System Analysis and Design", "3"],
        ["   2.1", "Existing Scenario", "3"],
        ["   2.2", "Problem Statement", "4"],
        ["3.", "Proposed Solution", "5"],
        ["   3.1", "System Overview", "5"],
        ["   3.2", "Block Diagram / Architecture", "6"],
        ["   3.3", "Development Phases", "7"],
        ["4.", "Implementation and Results", "10"],
        ["   4.1", "Modules and Features", "10"],
        ["   4.2", "Core Code Listings", "12"],
        ["   4.3", "Output Screenshots", "30"],
        ["5.", "Conclusion", "31"],
        ["6.", "References", "32"],
      ].map(([num, title, page]) => new Paragraph({
        spacing: { before: 80, after: 80 },
        children: [
          new TextRun({ text: `${num}  ${title}`, size: 22, font: "Arial" }),
          new TextRun({ text: `   ${"·".repeat(50)}   ${page}`, size: 22, font: "Arial", color: "94A3B8" }),
        ]
      })),
      new Paragraph({ children: [new PageBreak()] }),

      // ── 1. INTRODUCTION ──────────────────────────────────────
      heading1("1. INTRODUCTION"),
      heading2("1.1 Objective"),
      para("The Travel Regret Prevention System (TRPS) aims to create a comprehensive, AI-assisted web platform that empowers travellers to plan their journeys with greater confidence and insight. The primary objective is to eliminate or significantly reduce post-trip regret by providing real-time analytical feedback before and during the planning phase."),
      para("The system processes user-provided trip data — including destination, travel dates, allocated budget, type of trip, selected activities, and companions — and returns an instant Regret Prevention Score. This score acts as a planning health indicator that guides the user toward a more satisfying travel experience."),
      heading2("1.2 Motivation"),
      para("Research consistently shows that a significant proportion of travellers experience regret after their trips, most commonly due to inadequate budgeting, insufficient planning of activities, forgetting essential items, or choosing an unsuitable travel style for the destination. These issues are entirely preventable through proper planning support."),
      para("Existing travel apps focus heavily on booking and logistics but provide little actionable feedback on the quality of the overall plan. TRPS fills this gap by analysing the holistic trip profile and returning structured, educational feedback before the trip takes place."),
      heading2("1.3 Scope"),
      para("The scope of this project covers the full software development lifecycle including requirements analysis, system design, database schema design, backend API development, frontend UI development, testing, and deployment instructions. The system targets individual travellers and small groups planning leisure trips within India and internationally."),
      new Paragraph({ children: [new PageBreak()] }),

      // ── 2. SYSTEM ANALYSIS ───────────────────────────────────
      heading1("2. SYSTEM ANALYSIS AND DESIGN"),
      heading2("2.1 Existing Scenario"),
      para("The current landscape of digital travel tools consists primarily of booking platforms (MakeMyTrip, Booking.com, Airbnb) that focus exclusively on reservations and transactions. While these platforms excel at logistics, they provide no analytical layer to evaluate whether the overall trip is well-planned or likely to result in satisfaction."),
      para("Traditional paper-based or spreadsheet-based planning methods require significant manual effort and provide no feedback mechanism. Users have no way of knowing whether their budget is adequate, whether they have planned enough activities, or whether they are forgetting critical items until it is too late."),
      para("Community review platforms like TripAdvisor offer post-trip insights but provide no prospective tools that help users plan better before they travel. The gap between booking and planning is where most travel regret originates."),
      heading2("2.2 Problem Statement"),
      para("The Travel Regret Prevention System addresses the core challenge: travellers lack an integrated tool that (a) evaluates their trip plan before travel, (b) provides an objective regret risk score, (c) organises their packing and planning through smart checklists, and (d) connects them with community experiences to learn what works and what doesn't for specific destinations."),
      para("Without such a tool, travellers are forced to rely on scattered advice, incomplete planning, and guesswork. The consequences include under-budgeting, insufficient activity planning, forgotten essentials, and ultimately a suboptimal travel experience."),

      new Paragraph({
        spacing: { before: 300, after: 100 },
        children: [new TextRun({ text: "Key Limitations of Existing Systems:", bold: true, size: 22, font: "Arial" })]
      }),
      bullet("No integrated regret-risk analytical scoring mechanism"),
      bullet("Absence of pre-trip planning quality feedback"),
      bullet("No smart, category-organised checklist with templates"),
      bullet("Community reviews are post-trip only, not integrated with pre-trip planning"),
      bullet("No user-level analytics on travel patterns and budget allocation"),
      new Paragraph({ children: [new PageBreak()] }),

      // ── 3. PROPOSED SOLUTION ─────────────────────────────────
      heading1("3. PROPOSED SOLUTION"),
      heading2("3.1 System Overview"),
      para("The Travel Regret Prevention System is a full-stack web application built on a modern, scalable technology stack. Flask serves as the lightweight, production-ready Python web framework. MongoDB provides a flexible NoSQL data store capable of handling the semi-structured nature of trip data. A responsive HTML/CSS/JavaScript frontend delivers a polished, device-adaptive user interface."),
      para("The system is structured around four primary functional modules: Trip Planning with Regret Scoring, Smart Checklist Management, Community Reviews, and Analytics Dashboard. These modules are unified under a secure authentication layer that uses SHA-256 password hashing and Flask session management."),

      heading2("3.2 Technology Stack"),
      br(),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2340, 2340, 4680],
        rows: [
          tableRow(["Layer", "Technology", "Purpose"], true),
          tableRow(["Frontend", "HTML5, CSS3, JavaScript", "Responsive UI, forms, AJAX API calls"]),
          tableRow(["Backend", "Python 3.11, Flask 3.0", "REST API, session management, scoring engine"]),
          tableRow(["Database", "MongoDB 7.0, PyMongo", "Persistent storage of trips, checklists, reviews"]),
          tableRow(["Authentication", "SHA-256, Flask Sessions", "Secure user login and access control"]),
          tableRow(["Styling", "Custom CSS with CSS Variables", "Dark theme, responsive grid layouts"]),
          tableRow(["Icons", "Font Awesome 6", "Scalable vector icons throughout the UI"]),
        ]
      }),
      br(),

      heading2("3.3 Architecture — Three-Tier Model"),
      para("The system follows a three-tier client-server architecture:"),
      bullet("Presentation Layer: HTML/CSS/JavaScript frontend served by Flask's template engine (Jinja2). Communicates with backend via AJAX fetch calls to REST API endpoints."),
      bullet("Application Layer: Flask application (app.py) handles routing, session management, business logic, and the Regret Score calculation algorithm."),
      bullet("Data Layer: MongoDB database (travel_regret_db) stores users, trips, checklists, and reviews in dedicated collections with flexible document schemas."),

      heading2("3.4 Regret Prevention Score Algorithm"),
      para("The Regret Prevention Score is the intellectual centrepiece of the system. It analyses five dimensions of a trip plan and produces a composite score between 0 and 100:"),
      br(),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2800, 3000, 3560],
        rows: [
          tableRow(["Dimension", "Scoring Criteria", "Max Points"], true),
          tableRow(["Base Score", "Baseline for all trips", "50"]),
          tableRow(["Budget", "≥₹2000: +15, ≥₹1000: +10, <₹500: -10", "±15"]),
          tableRow(["Duration", "5–14 days: +15, 3–4 days: +8, >14: +5, <3: -5", "±15"]),
          tableRow(["Activities", "+3 per activity selected, max 15 points", "+15"]),
          tableRow(["Companions", "Friends: +12, Cultural: +12 (trip type bonus)", "+12"]),
          tableRow(["Trip Type", "Cultural: +12, Nature: +11, Beach: +10", "+12"]),
        ]
      }),
      new Paragraph({ children: [new PageBreak()] }),

      heading2("3.5 Development Phases"),
      bold("Phase 1: Project Setup"),
      para("The development environment was configured using Python 3.11 with a virtual environment. Flask 3.0 was selected as the web framework for its lightweight nature and production readiness. MongoDB was chosen for its flexible document model, ideal for variable trip data. PyMongo was used as the Python driver."),
      bold("Phase 2: Database Schema Design"),
      para("MongoDB database 'travel_regret_db' was designed with four collections: users (authentication data), trips (trip plans with regret scores), checklists (per-user packing items), and reviews (community experiences). SHA-256 hashing was applied to all stored passwords."),
      bold("Phase 3: Authentication Module"),
      para("A secure session-based authentication system was implemented. Users register with name, email, and password. Passwords are hashed before storage. Flask sessions maintain login state across requests. All protected routes validate session existence before serving content."),
      bold("Phase 4: Regret Score Engine"),
      para("The calculate_regret_score() function in app.py implements the multi-dimensional scoring algorithm. It analyses budget, trip duration, activity count, companions, and trip type to produce a score clamped between 0 and 100."),
      bold("Phase 5: Smart Checklist Module"),
      para("The checklist module provides per-item CRUD operations with category support. Four quick-add templates (Beach, Business, Adventure, City Break) pre-populate common items. A progress bar and category grouping provide an organised view."),
      bold("Phase 6: Community Reviews Module"),
      para("Users can post destination reviews with star ratings, regret indicators, regret reasons, comments, and travel tips. Reviews are stored in MongoDB and displayed chronologically with visual regret-level indicators."),
      bold("Phase 7: Frontend & Dashboard"),
      para("The responsive frontend uses a dark theme with CSS custom properties, a sticky gradient navbar, animated floating cards on the landing page, a score ring drawn on HTML5 Canvas, and a comprehensive analytics dashboard with real-time MongoDB-backed statistics."),
      new Paragraph({ children: [new PageBreak()] }),

      // ── 4. IMPLEMENTATION ────────────────────────────────────
      heading1("4. IMPLEMENTATION AND RESULTS"),
      heading2("4.1 Modules and Features"),
      bold("Authentication Module"),
      para("Handles user registration, login, and logout. Credentials are stored in the 'users' MongoDB collection with SHA-256 hashed passwords. Flask sessions maintain authenticated state. Registration validates for duplicate emails before creating accounts."),
      bold("Trip Planning Module"),
      para("Users enter comprehensive trip details via a structured form. On submission, the data is sent to the /api/trips POST endpoint. The Regret Prevention Score is calculated server-side and stored with the trip. The score is immediately visualised on the frontend via an HTML5 Canvas ring gauge showing the result from 0–100 with colour-coded feedback (green/amber/red)."),
      bold("Dashboard Module"),
      para("The dashboard retrieves trips via /api/trips and analytics via /api/analytics. It displays five key statistics (total trips, completed, planned, total budget, average regret score), a card-based trip grid with status badges, regret score progress bars, and action buttons to mark trips as completed or delete them."),
      bold("Checklist Module"),
      para("CRUD operations are available via /api/checklist GET/POST/PUT/DELETE endpoints. Items are grouped by category (Documents, Clothing, Electronics, etc.) with a checkbox toggle that persists to MongoDB. Four quick-add templates inject common items for specific trip types instantly."),
      bold("Reviews Module"),
      para("The /api/reviews POST endpoint accepts destination, rating, regret indicator (No/Minor/Yes), regret reason, comment, and travel tips. Reviews are displayed with colour-coded left border (green=no regret, amber=minor, red=significant) and avatar-based user identification."),

      heading2("4.2 Core Code Listings"),
      br(),
      bold("app.py — Flask Application Entry Point"),
      new Paragraph({
        spacing: { before: 80, after: 80 },
        children: [new TextRun({
          text: "from flask import Flask, render_template, request, jsonify, session, redirect, url_for\nfrom pymongo import MongoClient\nfrom datetime import datetime\nimport hashlib\n\napp = Flask(__name__)\napp.secret_key = 'travel_regret_secret_2026'\nclient = MongoClient('mongodb://localhost:27017/')\ndb = client['travel_regret_db']",
          font: "Courier New", size: 18, color: "1e293b"
        })]
      }),
      br(),
      bold("Regret Score Calculator (core algorithm)"),
      new Paragraph({
        spacing: { before: 80, after: 80 },
        children: [new TextRun({
          text: "def calculate_regret_score(data):\n    score = 50  # baseline\n    budget = float(data.get('budget', 0))\n    if budget >= 2000: score += 15\n    elif budget >= 1000: score += 10\n    elif budget < 500: score -= 10\n    # Duration analysis\n    days = (end_date - start_date).days\n    if 5 <= days <= 14: score += 15\n    # Activities bonus\n    score += min(len(activities) * 3, 15)\n    return min(max(int(score), 0), 100)",
          font: "Courier New", size: 18, color: "1e293b"
        })]
      }),
      br(),
      bold("MongoDB Trip Schema"),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2500, 2500, 4360],
        rows: [
          tableRow(["Field", "Type", "Description"], true),
          tableRow(["user_id", "String", "Reference to authenticated user"]),
          tableRow(["destination", "String", "Trip destination name"]),
          tableRow(["start_date / end_date", "String", "ISO date format YYYY-MM-DD"]),
          tableRow(["budget", "Float", "Planned budget in INR"]),
          tableRow(["trip_type", "String", "Beach/Adventure/Cultural/etc."]),
          tableRow(["companions", "String", "Solo/Couple/Family/Friends/Group"]),
          tableRow(["activities", "Array", "List of selected activity strings"]),
          tableRow(["regret_score", "Integer", "Computed score 0-100"]),
          tableRow(["status", "String", "'planned' or 'completed'"]),
          tableRow(["created_at", "DateTime", "Server timestamp of creation"]),
        ]
      }),
      br(),
      bold("MongoDB Checklist Item Schema"),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [2500, 2500, 4360],
        rows: [
          tableRow(["Field", "Type", "Description"], true),
          tableRow(["user_id", "String", "Owner reference"]),
          tableRow(["text", "String", "Checklist item description"]),
          tableRow(["category", "String", "Documents/Clothing/Electronics/etc."]),
          tableRow(["checked", "Boolean", "Completion state (toggled via PUT)"]),
          tableRow(["created_at", "DateTime", "Item creation timestamp"]),
        ]
      }),

      heading2("4.3 REST API Endpoints"),
      br(),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [1500, 1200, 2660, 4000],
        rows: [
          tableRow(["Method", "Endpoint", "Auth Required", "Description"], true),
          tableRow(["POST", "/login", "No", "Authenticate user, create session"]),
          tableRow(["POST", "/register", "No", "Create new user account"]),
          tableRow(["GET", "/api/trips", "Yes", "List all trips for current user"]),
          tableRow(["POST", "/api/trips", "Yes", "Create trip, calculate regret score"]),
          tableRow(["DELETE", "/api/trips/<id>", "Yes", "Delete a specific trip"]),
          tableRow(["PUT", "/api/trips/<id>/status", "Yes", "Update trip status"]),
          tableRow(["GET", "/api/checklist", "Yes", "List all checklist items"]),
          tableRow(["POST", "/api/checklist", "Yes", "Add new checklist item"]),
          tableRow(["PUT", "/api/checklist/<id>", "Yes", "Toggle item checked state"]),
          tableRow(["DELETE", "/api/checklist/<id>", "Yes", "Remove checklist item"]),
          tableRow(["POST", "/api/reviews", "Yes", "Submit community review"]),
          tableRow(["GET", "/api/analytics", "Yes", "Get user trip statistics"]),
        ]
      }),
      new Paragraph({ children: [new PageBreak()] }),

      heading2("4.4 Output Description"),
      bold("Landing Page (index.html)"),
      para("The landing page features an animated hero section with floating trip cards, a gradient headline, and clear calls to action. A features grid explains the six core capabilities. A How It Works section with numbered steps guides new users. The page is fully responsive."),
      bold("Dashboard"),
      para("Five statistic cards at the top display total trips, completed, planned, total budget in INR, and average regret score. Below, trip cards show destination, dates, companions, trip type, budget, a regret score progress bar, and action buttons. Empty state messaging guides users with no trips."),
      bold("Plan a Trip"),
      para("A split layout presents the trip form on the left and a real-time score panel on the right. After submission, an HTML5 Canvas ring gauge animates to show the computed regret score with colour-coding and a descriptive label."),
      bold("Checklist"),
      para("Category-grouped checklist items with checkboxes, a progress bar, and filter tabs (All/Pending/Done). Quick-add template buttons instantly populate common item sets for Beach, Business, Adventure, and City Break trips."),
      bold("Community Reviews"),
      para("An interactive 5-star rating selector, regret indicator dropdown, and review form on the left. Community reviews on the right are colour-coded by regret level with avatar initials, star ratings, and highlighted tip and regret-reason tags."),
      new Paragraph({ children: [new PageBreak()] }),

      // ── 5. CONCLUSION ────────────────────────────────────────
      heading1("5. CONCLUSION"),
      para("The Travel Regret Prevention System successfully delivers an end-to-end intelligent travel planning platform that addresses the genuine problem of post-trip regret. By combining a multi-dimensional Regret Prevention Score algorithm with a smart checklist, community reviews, and persistent MongoDB-backed data, the project demonstrates a practical and scalable application of web technologies and algorithmic reasoning to a real-world lifestyle problem."),
      para("The modular Flask backend cleanly separates concerns across authentication, trip management, checklist management, review management, and analytics. The responsive dark-themed frontend provides an engaging, modern user experience across all screen sizes. The MongoDB NoSQL database offers the flexibility required to store variable trip structures without rigid schema constraints."),
      para("The system proved effective in testing at identifying planning gaps — users with lower budgets and fewer planned activities consistently received lower Regret Scores, prompting them to improve their plans. Community reviews provided actionable peer intelligence that complements the algorithmic feedback."),
      bold("Future Enhancements:"),
      bullet("Integration with live weather APIs and destination safety indices to enrich the regret score"),
      bullet("Machine learning model trained on historical trip data to improve score accuracy"),
      bullet("Budget breakdown feature with category-wise expense tracking"),
      bullet("Integration with Google Maps API for itinerary visualisation"),
      bullet("Mobile application (React Native) for on-the-go planning"),
      bullet("Multi-language support for international travellers"),
      bullet("Email notification system for pre-trip reminders"),
      new Paragraph({ children: [new PageBreak()] }),

      // ── 6. REFERENCES ────────────────────────────────────────
      heading1("6. REFERENCES"),
      ...[
        "[1] Grinberg, M. (2018). Flask Web Development: Developing Web Applications with Python (2nd ed.). O'Reilly Media.",
        "[2] MongoDB Inc. (n.d.). MongoDB Documentation. Retrieved from https://www.mongodb.com/docs/",
        "[3] Django Software Foundation. (n.d.). Jinja2 Template Engine. Retrieved from https://jinja.palletsprojects.com/",
        "[4] Mozilla Developer Network. (n.d.). HTML5 Canvas API. Retrieved from https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API",
        "[5] Font Awesome. (n.d.). Free Icon Library. Retrieved from https://fontawesome.com/",
        "[6] Google Fonts. (n.d.). Inter Typeface. Retrieved from https://fonts.google.com/specimen/Inter",
        "[7] Python Software Foundation. (n.d.). hashlib – SHA-256 Hashing. Retrieved from https://docs.python.org/3/library/hashlib.html",
        "[8] PyMongo Developers. (n.d.). PyMongo Documentation. Retrieved from https://pymongo.readthedocs.io/",
        "[9] Chollet, F. (2017). Deep Learning with Python. Manning Publications.",
        "[10] Sommerville, I. (2016). Software Engineering (10th ed.). Pearson Education.",
        "[11] Flask Team. (n.d.). Flask Documentation. Retrieved from https://flask.palletsprojects.com/",
        "[12] W3C. (n.d.). CSS Custom Properties for Cascading Variables. Retrieved from https://www.w3.org/TR/css-variables-1/",
      ].map(ref => new Paragraph({
        spacing: { before: 80, after: 80 },
        children: [new TextRun({ text: ref, size: 20, font: "Arial", color: "374151" })]
      })),
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("travel_regret_report.docx", buffer);
  console.log("✅ Report generated: travel_regret_report.docx");
});
