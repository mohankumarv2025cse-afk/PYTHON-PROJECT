// ── Mobile Menu ─────────────────────────────────────────────────
function toggleMenu() {
  const links = document.querySelector(".nav-links");
  if (links) links.classList.toggle("open");
}

// ── Smooth scroll for anchor links ──────────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function (e) {
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
});

// ── Navbar active link highlight ─────────────────────────────────
const currentPath = window.location.pathname;
document.querySelectorAll(".nav-links a").forEach(link => {
  if (link.getAttribute("href") === currentPath) {
    link.style.color = "var(--text)";
    link.style.fontWeight = "700";
  }
});

// ── Fade-in on scroll ────────────────────────────────────────────
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1";
      entry.target.style.transform = "translateY(0)";
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll(".feature-card, .step, .trip-card, .review-card").forEach(el => {
  el.style.opacity = "0";
  el.style.transform = "translateY(20px)";
  el.style.transition = "opacity 0.5s ease, transform 0.5s ease";
  observer.observe(el);
});
